document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav-links');
  const mobileMenu = window.matchMedia('(max-width: 800px)');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

  document.documentElement.classList.add('js-enabled');

  const heroDate = document.querySelector('.hero-year');
  if (heroDate) {
    heroDate.textContent = new Intl.DateTimeFormat('en', { month: '2-digit', year: 'numeric' }).format(new Date());
  }

  const setMenuOpen = (open, returnFocus = false) => {
    if (!toggle || !nav) return;
    nav.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    if (returnFocus) toggle.focus();
  };

  toggle?.addEventListener('click', () => {
    setMenuOpen(toggle.getAttribute('aria-expanded') !== 'true');
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') {
      setMenuOpen(false, true);
    }
  });

  document.addEventListener('click', (event) => {
    if (toggle?.getAttribute('aria-expanded') === 'true' &&
        !nav?.contains(event.target) && !toggle.contains(event.target)) {
      setMenuOpen(false);
    }
  });

  mobileMenu.addEventListener('change', (event) => {
    if (!event.matches) setMenuOpen(false);
  });

  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener('click', (event) => {
      const target = link.getAttribute('href');
      if (!target || target === '#') return;
      const element = document.getElementById(target.slice(1));
      if (!element) return;

      event.preventDefault();
      element.scrollIntoView({
        behavior: reduceMotion.matches ? 'auto' : 'smooth',
        block: 'start'
      });
      setMenuOpen(false);
    });
  });

  const revealItems = document.querySelectorAll(
    '.build-card, .capabilities-grid article, .process-list article, .case-list article'
  );

  if (reduceMotion.matches || !('IntersectionObserver' in window)) {
    revealItems.forEach((item) => item.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries, instance) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        instance.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealItems.forEach((item) => observer.observe(item));
});